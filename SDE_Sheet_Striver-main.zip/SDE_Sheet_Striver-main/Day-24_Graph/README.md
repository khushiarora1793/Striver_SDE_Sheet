# Problems

SNo | Name | Logic Used | Link |
----|------|------------|------|
1 | Strongly Connected Components | Kosaraju's algo, dfs | [view](SCC_kosaraju.cpp) 
2 | Dijkstra Algo | minheap, relax(u, v) | [view](dijkstra_all_shortest_path.cpp)