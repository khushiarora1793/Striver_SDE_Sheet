# Problems

SNo | Name | Logic Used | Link |
----|------|------------|------|
1 | Reverse Words in a string | stack + conditions | [view](reverse_words.cpp)
2 | Longest Palindromic Substring | Two pointer consecutive + 1 gap apart expansion | [view](longest_palindromic_substring.cpp)
3 | Roman to integer | map, subtract if cur < next | [view](roman_to_integer.cpp)
4 | Integer to Roman | Store the exception symbols like 1, 4, 5, 9, etc | [view](integer_to_roman.cpp) 