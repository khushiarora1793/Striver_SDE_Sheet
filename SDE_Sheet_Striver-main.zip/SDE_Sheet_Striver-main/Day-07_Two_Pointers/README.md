# Problems

SNo | Name | Logic Used | Link |
----|------|------------|------|
1 | Copy List with random pointers | adjacent copy nodes | [view](clone_list.cpp)
2 | Three Sum 0 | sorting, 2 pointer approach | [view](Three_sum.cpp)
3 | Max consecutive ones | Kadane's algo | [view](max_consecutive_ones.cpp)
4 | remove duplicates in sorted array | 2 pointers | [view](remove_duplicates_sorted.cpp)
5 | Trapping Rainwater | 2 pointers, min(max_left, max_right) - arr[i] | [view](trapping_rainwater.cpp)